﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.RightsManagement;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace RestaurantAppetite
{
    internal class Dish
    {
        public int dishID;
        private int menuID;
        private string name, description;
        private double price;
        private byte[] image;
       
        public int MenuID
        {
            get { return menuID; }
            set { menuID = value; }
        }
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public string Description
        {
            get { return description; }
            set { description = value; }
        }
        public double Price
        {
            get { return price; }
            set { price = value; }
        }
        public byte[] Image
        {
            get { return image; }
            set { image = value; }
        }
        public BitmapImage ImageSource
        {
            get
            {
                return Image != null ? ConvertByteArrayToImage(Image) : null;
            }
        }
        public Dish() { }
        public Dish(int menuID, string name, string description, double price, byte[] image)
        {
            this.menuID = menuID;
            this.name = name;
            this.description = description;
            this.price = price;
            this.image = image;
        }
        private BitmapImage ConvertByteArrayToImage(byte[] byteArray)
        {
            using (var ms = new MemoryStream(byteArray))
            {
                BitmapImage image = new BitmapImage();
                image.BeginInit();
                image.StreamSource = ms;
                image.CacheOption = BitmapCacheOption.OnLoad;
                image.EndInit();
                image.Freeze(); 
                return image;
            }
        }
    }
}

