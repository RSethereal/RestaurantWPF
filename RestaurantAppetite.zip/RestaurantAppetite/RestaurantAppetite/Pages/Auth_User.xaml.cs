﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RestaurantAppetite.Pages
{
    /// <summary>
    /// Логика взаимодействия для Auth_User.xaml
    /// </summary>
    public partial class Auth_User : Window
    {
        ApplicationContext db;
        public Auth_User()
        {
            db = new ApplicationContext();
            InitializeComponent();
        }

        private void Button_Reg_Click(object sender, RoutedEventArgs e)
        {
           
            string login = textLogin.Text.Trim();
            string password = textPassword.Password.Trim();
            string password2 = textPassword2.Password.Trim();
            string email = textEmail.Text.Trim().ToLower();
            string phoneNumber = textPhone.Text.Trim();

            //проверка существущих данных в бд

            User isLogin = new User();
            User isEmail = new User();
            User isPhone = new User();

            using(ApplicationContext db = new ApplicationContext())
            {
                isLogin = db.Users.Where(b => b.UserName == login).FirstOrDefault();
                isEmail = db.Users.Where(b => b.Email == email).FirstOrDefault();
                isPhone = db.Users.Where(b => b.PhoneNumber == phoneNumber).FirstOrDefault();
            }


            if (login.Length < 3)
            {
                textLogin.ToolTip = "Логин должен содержать больше 3 символов!";
                textLogin.Background = Brushes.LightPink;
            }
            else if(password.Length<3)
            {
                textPassword.ToolTip = "Пароль должен содержать больше 3 символов!";
                textPassword.Background = Brushes.LightPink;
            }
            else if(password != password2)
            {
                textPassword2.ToolTip = "Пароль не совпадает!";
                textPassword2.Background = Brushes.LightPink;
            }
            else if (!email.Contains("@") || !email.Contains("."))
            {
                textEmail.ToolTip = "Некорректно введенная эл. почта";
                textEmail.Background = Brushes.LightPink;
            }
            else if (phoneNumber.Length < 10)
            {
                textPhone.ToolTip = "Некорректно введен номер телефона";
                textEmail.Background = Brushes.LightPink;
            }
            else if(isLogin != null)
            {
                textLogin.ToolTip = "Пользователь с таким паролем уже зарегистрирован";
                textLogin.Background = Brushes.LightPink;
            }
            else if (isEmail != null)
            {
                textEmail.ToolTip = "Пользователь с такой эл. почтой уже зарегистрирован";
                textEmail.Background = Brushes.LightPink;
            }
            else if (isPhone != null)
            {
                textPhone.ToolTip = "Пользователь с таким номером телефона уже зарегистрирован";
                textPhone.Background = Brushes.LightPink;
            }
            else
            {
                textLogin.ToolTip = "";
                textLogin.Background = Brushes.Transparent;
                textPassword.ToolTip = "";
                textPassword.Background = Brushes.Transparent;
                textPassword2.ToolTip = "";
                textPassword2.Background = Brushes.Transparent;
                textEmail.ToolTip = "";
                textEmail.Background = Brushes.Transparent;

                User user = new User(login, email,password,phoneNumber);
                db.Users.Add(user);
                db.SaveChanges();

                MainPage page = new MainPage();
                this.Hide();
                page.Show();
            }
        }

        private void Button_LogIn_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            this.Hide();
            main.Show();
        }
    }
}
