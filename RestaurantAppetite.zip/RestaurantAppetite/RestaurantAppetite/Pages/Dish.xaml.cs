﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RestaurantAppetite.Pages
{
    /// <summary>
    /// Логика взаимодействия для Dish.xaml
    /// </summary>
    public partial class Dish : Window
    {
        public Dish(string name, string description, decimal price, byte[] image)
        {
            InitializeComponent();
            NameTextBlock.Text = name;
            DescriptionTextBlock.Text = description;
            PriceTextBlock.Text = $"Цена: {price} руб.";

            if (image != null)
            {
                using (var ms = new MemoryStream(image))
                {
                    var bitmap = new BitmapImage();
                    bitmap.BeginInit();
                    bitmap.CacheOption = BitmapCacheOption.OnLoad;
                    bitmap.StreamSource = ms;
                    bitmap.EndInit();
                    DishImage.Source = bitmap;
                }
            }
        }
    }
}
