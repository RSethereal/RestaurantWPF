﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RestaurantAppetite.Pages
{
    /// <summary>
    /// Логика взаимодействия для MainPage.xaml
    /// </summary>
    public partial class MainPage : Window
    {
        public MainPage()
        {
            InitializeComponent();
            LoadData();
        }
        private void ListViewItem_MouseEnter(object sender, MouseEventArgs e)
        {
            if (Tg_btn.IsChecked == true)
            {
                tt_Home.Visibility = Visibility.Collapsed;
                tt_Profil.Visibility = Visibility.Collapsed;
                tt_Menu.Visibility = Visibility.Collapsed;
                tt_Reserv.Visibility = Visibility.Collapsed;
                tt_Exit.Visibility = Visibility.Collapsed;
            }
            else
            {
                tt_Home.Visibility = Visibility.Visible;
                tt_Profil.Visibility = Visibility.Visible;
                tt_Menu.Visibility = Visibility.Visible;
                tt_Reserv.Visibility = Visibility.Visible;
                tt_Exit.Visibility= Visibility.Visible;
            }
        }

        private void Tg_btn_Checked(object sender, RoutedEventArgs e)
        {
            img.Opacity = 0.3;
            grid_opacity.Opacity = 0.1;
        }

        private void Tg_btn_Unchecked(object sender, RoutedEventArgs e)
        {
            img.Opacity = 1;
            grid_opacity.Opacity = 1;
        }

        private void Bd_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void BG_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Tg_btn.IsChecked = false;
        }
        private void LoadData()
        {
            HelperRes dbHelper = new HelperRes();
            ResName.Text = dbHelper.GetName();
            ResDescription.Text = dbHelper.GetDes();
            ResNumb.Text = dbHelper.GetNumb();
            ResHours.Text = dbHelper.GetHours();
            ResAddress.Text = dbHelper.GetAddress();
        }

        private void Button_Profil_Click(object sender, RoutedEventArgs e)
        {
            Profil pr = new Profil();
            this.Hide();
            pr.Show();
        }

        private void Button_Dishes_Click(object sender, RoutedEventArgs e)
        {
            MenuDishes pg = new MenuDishes();
            this.Hide();
            pg.Show();
        }

        private void Button_Reserv_Click(object sender, RoutedEventArgs e)
        {
            ReservWindow pg = new ReservWindow();
            this.Hide();
            pg.Show();
        }

        private void Button_Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
