﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RestaurantAppetite.Pages
{
    /// <summary>
    /// Логика взаимодействия для MenuDishes.xaml
    /// </summary>
    public partial class MenuDishes : Window
    {
        DataSet set = new DataSet();
        public string connectionString = ConfigurationManager.ConnectionStrings["RestaurantAppetite.Properties.Settings.RestaurantConnectionString"].ConnectionString;
        public string query = "select Dishes.Image as [Фото], Menu.Category as [Категория],Dishes.Name as [Название блюда], Dishes.Description as [Описание],Dishes.Price as [Цена] from Menu inner join Dishes on Menu.MenuID = Dishes.MenuID";
        public class YourDataModel
        {
            public byte[] Image { get; set; }
        }
        public MenuDishes()
        {
            InitializeComponent();
            LoadCategories();


        }
        private void ListViewItem_MouseEnter(object sender, MouseEventArgs e)
        {
            if (Tg_btn.IsChecked == true)
            {
                tt_Home.Visibility = Visibility.Collapsed;
                tt_Profil.Visibility = Visibility.Collapsed;
                tt_Menu.Visibility = Visibility.Collapsed;
                tt_Reserv.Visibility = Visibility.Collapsed;
                tt_Exit.Visibility = Visibility.Collapsed;
            }
            else
            {
                tt_Home.Visibility = Visibility.Visible;
                tt_Profil.Visibility = Visibility.Visible;
                tt_Menu.Visibility = Visibility.Visible;
                tt_Reserv.Visibility= Visibility.Visible;
                tt_Exit.Visibility= Visibility.Visible;
            }
        }

        private void Tg_btn_Checked(object sender, RoutedEventArgs e)
        {
            img.Opacity = 0.3;
            grid_opacity.Opacity = 0.1;
        }

        private void Tg_btn_Unchecked(object sender, RoutedEventArgs e)
        {
            img.Opacity = 1;
            grid_opacity.Opacity = 1;
        }

        private void Bd_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void BG_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Tg_btn.IsChecked = false;
        }

        private void Button_Profil_Click(object sender, RoutedEventArgs e)
        {
            Profil pg = new Profil();
            this.Hide();
            pg.Show();
        }

        private void Button_Main_Click(object sender, RoutedEventArgs e)
        {
            MainPage pg = new MainPage();
            this.Hide();
            pg.Show();
        }
        private void Button_Reserv_Click(object sender, RoutedEventArgs e)
        {
            ReservWindow pg = new ReservWindow();
            this.Hide();
            pg.Show();
        }

        private void Button_Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
        private void LoadCategories()
        {

            string sql = "select Category from Menu";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(sql, connection);
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {

                        comboBox.Items.Add(reader["Category"]).ToString();

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка: " + ex.Message);
                }
            }
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    adapter.Fill(set, "Dishes");

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка: " + ex.Message);
                }
            }

        }

        private void comboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string nameCateg = comboBox.SelectedItem.ToString();
            LoadMenuToGrid(nameCateg);
        }
        private void LoadMenuToGrid(string category)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    DataView dv = new DataView(set.Tables["Dishes"], $"[Категория] = '{category}'", "[Название блюда] Desc", DataViewRowState.CurrentRows);
                    grid.ItemsSource = dv;
                    grid.Columns[2].Visibility = Visibility.Collapsed;
                    grid.Columns[4].Visibility = Visibility.Collapsed;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка: " + ex.Message);
                }
            }
        }

        private void grid_AutoGeneratingColumn(object sender, DataGridAutoGeneratingColumnEventArgs e)
        {
            
            if (e.PropertyName == "Фото")
            {

                var imageColumn = new DataGridTemplateColumn();
                imageColumn.Header = "Фото";

                var dataTemplate = new DataTemplate();
                var imageFactory = new FrameworkElementFactory(typeof(Image));
                imageFactory.SetBinding(Image.SourceProperty, new Binding("Фото")
                {
                    Converter = (IValueConverter)FindResource("ByteArrayToImageConverter")
                });
                imageFactory.SetValue(Image.WidthProperty, 100.0);
                imageFactory.SetValue(Image.HeightProperty, 100.0);

                dataTemplate.VisualTree = imageFactory;
                imageColumn.CellTemplate = dataTemplate;
                e.Column = imageColumn;
            }
        
        }
        private List<OrderItem> cartItems = new List<OrderItem>(); // список для хранения элементов заказа
        private string GetSelectedDishName()
        {
            string name = "";
            if (grid.SelectedItem is DataRowView selectedRow)
            {
                name = selectedRow["Название блюда"].ToString();

            }
            return name;
        }

        private decimal GetSelectedDishPrice()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                decimal price = 0;
                if (grid.SelectedItem is DataRowView selectedRow)
                {
                    price = Convert.ToDecimal(selectedRow["Цена"]);
                }
                return price;
            }
        }
        

        private void AddDishToCart(string name, decimal price)
        {
            // ID блюда из базы данных
            int dishId = GetDishIdByName(name); 

            // увеличиваем количество, если такое блюдо уже есть в корзине
            var existingItem = cartItems.FirstOrDefault(item => item.DishID == dishId);
            if (existingItem != null)
            {
                existingItem.Quantity++;
            }
            else
            {
                cartItems.Add(new OrderItem { DishID = dishId, Quantity = 1 });
            }

            // Обновление отображение корзины
            UpdateCartGrid();
        }
        private void UpdateCartGrid()
        {
            // Отображаем элементы корзины в DataGrid
            cartGrid.ItemsSource = cartItems.Select(item => new
            {
                DishName = GetDishNameById(item.DishID), 
                item.Quantity,
                TotalPrice = item.Quantity * GetDishPriceById(item.DishID) 
            }).ToList();
        }

        private void PlaceOrder(string address)
        {
            // создание нового заказа
            Order newOrder = new Order
            {
                OrderDate = DateTime.Now,
                Status = "доставлен",
                TotalAmount = cartItems.Sum(item => item.Quantity * GetDishPriceById(item.DishID)), // счет общей суммы
                Address = address
            };

            // сохранение заказа в базе данных
            SaveOrder(newOrder);

            // получчение ID созданного заказа
            int orderId = GetLastOrderId();

            // Сохранение элементов заказа в базе данных
            foreach (var item in cartItems)
            {
                SaveOrderItem(new OrderItem
                {
                    OrderID = orderId,
                    DishID = item.DishID,
                    Quantity = item.Quantity
                });
            }

            // Очищаем корзину после оформления заказа
            cartItems.Clear();
            UpdateCartGrid();
        }

        //вспомогательные методы

        private int GetDishIdByName(string name)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                connection.Open();
                SqlCommand command = new SqlCommand("SELECT DishID FROM Dishes WHERE Name = @name", connection);
                command.Parameters.AddWithValue("@name", name);
                return (int)command.ExecuteScalar();
            }
        }

        private string GetDishNameById(int dishId)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                var command = new SqlCommand("SELECT Name FROM Dishes WHERE DishID = @dishId", connection);
                command.Parameters.AddWithValue("@dishId", dishId);
                return (string)command.ExecuteScalar();
            }
        }
        private decimal GetDishPriceById(int dishId)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                var command = new SqlCommand("SELECT Price FROM Dishes WHERE DishID = @dishId", connection);

                command.Parameters.AddWithValue("@dishId", dishId);
                return (decimal)command.ExecuteScalar();
            }
        }
        private void SaveOrder(Order order)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                var command = new SqlCommand("INSERT INTO Orders (UserID, RestaurantID, OrderDate, Status, TotalAmount, Address) VALUES (1, 1, @date, @status, @total, @address)", connection);
                command.Parameters.AddWithValue("@date", order.OrderDate);
                command.Parameters.AddWithValue("@status", order.Status);
                command.Parameters.AddWithValue("@total", order.TotalAmount);
                command.Parameters.AddWithValue("@address", order.Address);
                command.ExecuteNonQuery();
            }
        }

        private int GetLastOrderId()
        {
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                var command = new SqlCommand("SELECT MAX(OrderID) FROM Orders", connection);
                return (int)command.ExecuteScalar();
            }
        }

        private void SaveOrderItem(OrderItem orderItem)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                var command = new SqlCommand("INSERT INTO OrderItems (OrderID, DishID, Quantity) VALUES (@orderId, @dishId, @quantity)", connection);
                command.Parameters.AddWithValue("@orderId", orderItem.OrderID);
                command.Parameters.AddWithValue("@dishId", orderItem.DishID);
                command.Parameters.AddWithValue("@quantity", orderItem.Quantity);
                command.ExecuteNonQuery();
            }
        }

        private void PlaceOrderButton_Click(object sender, RoutedEventArgs e)
        {
            string address = PromptForAddress(); // Метод для запроса адреса у пользователя
            if (!string.IsNullOrEmpty(address))
            {
                PlaceOrder(address); // Оформляем заказ
                MessageBox.Show("Заказ оформлен успешно!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                DeliveryWindow deliveryWindow = new DeliveryWindow();
                deliveryWindow.ShowDialog();
                Order order = new Order();

            }
        }

        private void AddToCartButton_Click(object sender, RoutedEventArgs e)
        {
            // имя блюда и его цена из интерфейса
            string dishName = GetSelectedDishName(); // Метод для получения имени выбранного блюда
            decimal dishPrice = GetSelectedDishPrice(); // Метод для получения цены выбранного блюда
            AddDishToCart(dishName, dishPrice);
        }
        private string PromptForAddress()
        {
            var addressWindow = new Window
            {
                Title = "Введите адрес",
                Width = 300,
                Height = 150,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                Owner = this
            };

 
            var addressTextBox = new TextBox()
            {
                Margin = new Thickness(10),
                Width = 250,
                Height = 30,
                Name = "AddressTextBox"
            };

        
            var okButton = new Button
            {
                Content = "ОК",
                Margin = new Thickness(10),
                Width = 75,
                Height = 30
            };


            // обработчик события нажатия на кнопку
            okButton.Click += (sender, e) =>
            {

                // закрытие окна и установление результата
                addressWindow.DialogResult = true;
                addressWindow.Close();
            };

            var stackPanel = new StackPanel();
            stackPanel.Children.Add(addressTextBox);
            stackPanel.Children.Add(okButton);


            // Устанавливаем содержимое окна
            addressWindow.Content = stackPanel;

            // Показываем окно как модальное
            var result = addressWindow.ShowDialog();

            // Если результат успешный, возвращаем текст из текстового поля
            if (result == true)
            {
                return addressTextBox.Text;
            }
            // Если окно было закрыто без ввода, возвращаем null
            return null;
        }

        private void grid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (grid.SelectedItem is DataRowView selectedRow)
            {
                string name = selectedRow["Название блюда"].ToString();
                string description = selectedRow["Описание"].ToString();
                decimal price = Convert.ToDecimal(selectedRow["Цена"]);
                byte[] image = selectedRow["Фото"] as byte[];

                Dish detailsWindow = new Dish(name, description, price, image);
                detailsWindow.ShowDialog();
            }
        }
    }
    public class ByteArrayToImageConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value is byte[] imageData && imageData.Length > 0)
            {
                using (var stream = new MemoryStream(imageData))
                {
                    var bitmap = new BitmapImage();
                    bitmap.BeginInit();
                    bitmap.CacheOption = BitmapCacheOption.OnLoad;
                    bitmap.StreamSource = stream;
                    bitmap.EndInit();
                    bitmap.Freeze();
                    return bitmap;
                }
            }
            return null; // Возвращает null, если нет данных изображения
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

    }
}

