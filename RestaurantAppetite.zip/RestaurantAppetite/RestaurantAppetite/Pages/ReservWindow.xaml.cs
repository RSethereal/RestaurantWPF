﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RestaurantAppetite.Pages
{
    /// <summary>
    /// Логика взаимодействия для ReservWindow.xaml
    /// </summary>
    public partial class ReservWindow : Window
    {
        public string connectionString = ConfigurationManager.ConnectionStrings["RestaurantAppetite.Properties.Settings.RestaurantConnectionString"].ConnectionString;

        public ReservWindow()
        {
            InitializeComponent();
        }

        private void Button_Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void Button_Main_Click(object sender, RoutedEventArgs e)
        {
            MainPage pg = new MainPage();
            this.Hide();
            pg.Show();
        }

        private void Button_Profil_Click(object sender, RoutedEventArgs e)
        {
            Profil pg = new Profil();
            this.Hide();
            pg.Show();
        }

        private void Button_Menu_Click(object sender, RoutedEventArgs e)
        {
            MenuDishes pg = new MenuDishes();
            this.Hide();
            pg.Show();

        }
        private void ListViewItem_MouseEnter(object sender, MouseEventArgs e)
        {
            if (Tg_btn.IsChecked == true)
            {
                tt_Home.Visibility = Visibility.Collapsed;
                tt_Profil.Visibility = Visibility.Collapsed;
                tt_Menu.Visibility = Visibility.Collapsed;
                tt_Reserv.Visibility = Visibility.Collapsed;
                tt_Exit.Visibility = Visibility.Collapsed;
            }
            else
            {
                tt_Home.Visibility = Visibility.Visible;
                tt_Profil.Visibility = Visibility.Visible;
                tt_Menu.Visibility = Visibility.Visible;
                tt_Reserv.Visibility = Visibility.Visible;
                tt_Exit.Visibility = Visibility.Visible;
            }
        }

        private void Tg_btn_Checked(object sender, RoutedEventArgs e)
        {
            img.Opacity = 0.3;
            grid_opacity.Opacity = 0.1;
        }

        private void Tg_btn_Unchecked(object sender, RoutedEventArgs e)
        {
            img.Opacity = 1;
            grid_opacity.Opacity = 1;
        }

        private void Bd_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void BG_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Tg_btn.IsChecked = false;
        }

        private void ShowAvailableTables_Click(object sender, RoutedEventArgs e)
        {
            if (datePicker.SelectedDate.HasValue && !string.IsNullOrWhiteSpace(timeTextBox.Text) && guestCountComboBox.SelectedItem != null)
            {
                DateTime selectedDateTime;

                ///распарсить введенное время
                if (DateTime.TryParseExact(timeTextBox.Text, "HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime time))
                {
                    selectedDateTime = datePicker.SelectedDate.Value.Date + time.TimeOfDay;
                    int guestCount = int.Parse(((ComboBoxItem)guestCountComboBox.SelectedItem).Content.ToString());

                    List<int> availableTables = GetAvailableTables(selectedDateTime, guestCount);
                    listBoxAvailableTables.ItemsSource = availableTables;
                }
                else
                {
                    MessageBox.Show("Неверный формат времени. Пожалуйста, введите время в формате HH:mm.","Ошибка!",MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите дату, введите время и количество гостей.","Ошибка!", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
        //метод для выявления свободных столиков
        private List<int> GetAvailableTables(DateTime dateTime, int guestCount)
        {
            List<int> availableTables = new List<int>();
            DateTime endTime = dateTime.AddHours(2);
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                // Получаем все столики
                string query = "SELECT TableNumber FROM Tables WHERE AllGuestCount >= @GuestCount AND TableNumber NOT IN (SELECT TableNumber FROM Reservations WHERE ReservationDateTime BETWEEN @StartTime AND @EndTime)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@GuestCount", guestCount);
                command.Parameters.AddWithValue("@StartTime", dateTime);
                command.Parameters.AddWithValue("@EndTime", endTime);

                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    availableTables.Add(reader.GetInt32(0));
                }
            }

            return availableTables;
        }
        private void ReserveTable_Click(object sender, RoutedEventArgs e)
        {
            if (listBoxAvailableTables.SelectedItem != null)
            {
                int selectedTableNumber = (int)listBoxAvailableTables.SelectedItem;
                DateTime selectedDateTime;

                //распарсить введенное время
                if (DateTime.TryParseExact(timeTextBox.Text, "HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime time))
                {
                    selectedDateTime = datePicker.SelectedDate.Value.Date + time.TimeOfDay;

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "INSERT INTO Reservations (UserID, ReservationDateTime, GuestCount, TableNumber) VALUES (1, @ReservationDateTime, @GuestCount, @TableNumber)";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@ReservationDateTime", selectedDateTime);
                        command.Parameters.AddWithValue("@GuestCount", int.Parse(((ComboBoxItem)guestCountComboBox.SelectedItem).Content.ToString()));
                        command.Parameters.AddWithValue("@TableNumber", selectedTableNumber);
                        command.ExecuteNonQuery();
                    }

                    MessageBox.Show($"Стол № {selectedTableNumber} зарезервирован на {selectedDateTime}, ждем вас!", "Столик забронирован!", MessageBoxButton.OK, MessageBoxImage.Information);
                    listBoxAvailableTables.ItemsSource = null;
                    guestCountComboBox.Items.Clear();
                    timeTextBox.Text = string.Empty;
                }
                else
                {
                    MessageBox.Show("Неверный формат времени. Пожалуйста, введите время в формате HH:mm.", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите столик для бронирования.", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }
}
