﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RestaurantAppetite.Pages
{
    /// <summary>
    /// Логика взаимодействия для Profil.xaml
    /// </summary>
    public partial class Profil : Window
    {
        public DataSet set = new DataSet();
        public string connection = ConfigurationManager.ConnectionStrings["RestaurantAppetite.Properties.Settings.RestaurantConnectionString"].ConnectionString;
        public Profil()
        {
            InitializeComponent();
            LoadDataOrders();
            LoadDataResv();
        }
        private void ListViewItem_MouseEnter(object sender, MouseEventArgs e)
        {
            if (Tg_btn.IsChecked == true)
            {
                tt_Home.Visibility = Visibility.Collapsed;
                tt_Profil.Visibility = Visibility.Collapsed;
                tt_Menu.Visibility = Visibility.Collapsed;
                tt_Reserv.Visibility = Visibility.Collapsed;
                tt_Exit.Visibility = Visibility.Collapsed;
            }
            else
            {
                tt_Home.Visibility = Visibility.Visible;
                tt_Profil.Visibility = Visibility.Visible;
                tt_Menu.Visibility = Visibility.Visible;
                tt_Reserv.Visibility = Visibility.Visible;
                tt_Exit.Visibility= Visibility.Visible;
            }
        }

        private void Tg_btn_Checked(object sender, RoutedEventArgs e)
        {
            img.Opacity = 0.3;
            grid_opacity.Opacity = 0.1;
        }

        private void Tg_btn_Unchecked(object sender, RoutedEventArgs e)
        {
            img.Opacity = 1;
            grid_opacity.Opacity = 1;
        }

        private void Bd_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void BG_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Tg_btn.IsChecked = false;
        }

        private void Button_Main_Click(object sender, RoutedEventArgs e)
        {
            MainPage main = new MainPage();
            this.Hide();
            main.Show();
        }
        private void Button_Dishes_Click(object sender, RoutedEventArgs e)
        {
            MenuDishes pg = new MenuDishes();
            this.Hide();
            pg.Show();
        }
        public void LoadDataOrders()
        {
            string sql = "select OrderID as [Номер], TotalAmount as [Сумма], Status as [Статус] from Orders";
            using (SqlConnection con = new SqlConnection(connection))
            {
                con.Open();
                SqlCommand command = new SqlCommand(sql, con);
                SqlDataAdapter adapter = new SqlDataAdapter(command);

                adapter.Fill(set, "userOrders");
                UserOrders.ItemsSource = set.Tables["userOrders"].DefaultView;
                UserOrders.Columns[0].Visibility = Visibility.Collapsed;
            }
        }
        public void LoadDataResv()
        {
            string sql = "select CONVERT(VARCHAR(16), ReservationDateTime, 120) as [Дата и время],CONVERT(VARCHAR(10), GuestCount) as [Кол-во гостей] from Reservations";
            using (SqlConnection con = new SqlConnection(connection))
            {
                con.Open();
                SqlCommand command = new SqlCommand(sql, con);
                SqlDataAdapter adapter = new SqlDataAdapter(command);

                adapter.Fill(set, "userReserv");
                userReserv.ItemsSource = set.Tables["userReserv"].DefaultView;
                userReserv.Columns[0].Visibility = Visibility.Collapsed;
            }
        }

        private void Button_Reserv_Click(object sender, RoutedEventArgs e)
        {
            ReservWindow pg = new ReservWindow();
            this.Hide();
            pg.Show();
        }

        private void Button_Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
