﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace RestaurantAppetite.Pages
{
    /// <summary>
    /// Логика взаимодействия для DeliveryWindow.xaml
    /// </summary>
    public partial class DeliveryWindow : Window
    {
        private DispatcherTimer timer;
        private int elapsedSeconds = 0;
        public DeliveryWindow()
        {
            InitializeComponent();
            StartAnimation();
        }
        private void StartAnimation()
        {
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += Timer_Tick;
            timer.Start();
        }
        private void Timer_Tick(object sender, EventArgs e)
        {
            elapsedSeconds++;
        
            if (elapsedSeconds >= 10)
            {
                timer.Stop();
                StatusTextBlock.Text = "Ваш заказ доставлен";
                OkButton.Visibility = Visibility.Visible;
                MovingImage.Visibility = Visibility.Collapsed;
            }
        }
        public string connectionString = ConfigurationManager.ConnectionStrings["RestaurantAppetite.Properties.Settings.RestaurantConnectionString"].ConnectionString;
        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        
    }
}
