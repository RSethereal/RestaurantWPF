﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantAppetite
{
    internal class Menu
    {
        public int menuID { get;set; }
        private string category;
        public string Category
        {
            get { return category; }
            set { category = value; }
        }
        public Menu() { }
        public Menu(string category)
        {
            this.category = category;
        }
    }
}
