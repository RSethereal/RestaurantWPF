﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantAppetite
{
    internal class HelperRes
    {
        
        public string GetName()
        {
            string result = string.Empty;
            string connectionString = ConfigurationManager.ConnectionStrings["RestaurantAppetite.Properties.Settings.RestaurantConnectionString"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT Name FROM Restaurants"; 
                SqlCommand command = new SqlCommand(query, connection);
                try
                {
                    connection.Open();
                    result = command.ExecuteScalar()?.ToString();
                }
                catch (Exception ex)
                {
                    result = $"Ошибка: {ex.Message}";
                }
            }
            return result;
        }
        public string GetDes()
        {
            string result = string.Empty;
            string connectionString = ConfigurationManager.ConnectionStrings["RestaurantAppetite.Properties.Settings.RestaurantConnectionString"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT Description FROM Restaurants";
                SqlCommand command = new SqlCommand(query, connection);
                try
                {
                    connection.Open();
                    result = command.ExecuteScalar()?.ToString();
                }
                catch (Exception ex)
                {
                    result = $"Ошибка: {ex.Message}";
                }
            }
            return result;
        }
        public string GetNumb()
        {
            string result = string.Empty;
            string connectionString = ConfigurationManager.ConnectionStrings["RestaurantAppetite.Properties.Settings.RestaurantConnectionString"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT PhoneNumber FROM Restaurants";
                SqlCommand command = new SqlCommand(query, connection);
                try
                {
                    connection.Open();
                    result = command.ExecuteScalar()?.ToString();
                }
                catch (Exception ex)
                {
                    result = $"Ошибка: {ex.Message}";
                }
            }
            return result;
        }
        public string GetHours()
        {
            string result = string.Empty;
            string connectionString = ConfigurationManager.ConnectionStrings["RestaurantAppetite.Properties.Settings.RestaurantConnectionString"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT OpeningHours FROM Restaurants";
                SqlCommand command = new SqlCommand(query, connection);
                try
                {
                    connection.Open();
                    result = command.ExecuteScalar()?.ToString();
                }
                catch (Exception ex)
                {
                    result = $"Ошибка: {ex.Message}";
                }
            }
            return result;
        }
        public string GetAddress()
        {
            string result = string.Empty;
            string connectionString = ConfigurationManager.ConnectionStrings["RestaurantAppetite.Properties.Settings.RestaurantConnectionString"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT Address FROM Restaurants";
                SqlCommand command = new SqlCommand(query, connection);
                try
                {
                    connection.Open();
                    result = command.ExecuteScalar()?.ToString();
                }
                catch (Exception ex)
                {
                    result = $"Ошибка: {ex.Message}";
                }
            }
            return result;
        }
    }
}
