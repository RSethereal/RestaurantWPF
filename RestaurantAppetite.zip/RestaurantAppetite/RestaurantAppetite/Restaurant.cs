﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.RightsManagement;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantAppetite
{
    public class Restaurant
    {
        public int restaurantID { get; set; }
        private string name, description, address, phoneNumber, openingHours;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        public string Address
        {
            get { return address; }
            set { address = value; }
        }
        public string PhoneNumber
        {
            get { return phoneNumber; }
            set { phoneNumber = value; }
        }
        public string OpeningHours
        {
            get { return openingHours; }
            set { openingHours = value; }
        }
        public Restaurant() { }
        public Restaurant(string name, string description, string address, string phoneNumber, string openingHours)
        {
            this.name = name;
            this.description = description;
            this.address = address;
            this.phoneNumber = phoneNumber;
            this.openingHours = openingHours;
        }
    }
}
